import csv

from py2neo import Graph, Node, Relationship


def create_character(graph: Graph, character):
    c = Node("Character", **character)
    p = Node("Planet", name=character['homeworld'])
    s = Node("Species", name=character['species'])
    graph.merge(c, "Character", "name")
    graph.merge(p, "Planet", "name")
    graph.merge(s, "Species", "name")
    graph.merge(Relationship(c, "FROM", p))
    graph.merge(Relationship(c, "IDENTIFIED_AS", s))


def create_planet(graph: Graph, planet):
    p = Node("Planet", **planet)
    graph.merge(p, "Planet", "name")


def create_species(graph: Graph, species):
    s = Node("Species", **species)
    p = Node("Planet", name=species['homeworld'])
    graph.merge(s, "Species", "name")
    graph.merge(p, "Planet", "name")
    graph.merge(Relationship(s, "ORIGINATED_FROM", p))


def seed_data(graph):
    # empty the database
    print("Deleting all nodes and relationships")
    graph.delete_all()

    # seed data into the database
    print("Seeding data into database")
    with open("files/planets.csv", "r") as file:
        reader = csv.DictReader(file)
        for row in reader:
            create_planet(graph, row)

    with open("files/characters.csv", "r") as file:
        reader = csv.DictReader(file)
        for row in reader:
            create_character(graph, row)

    with open("files/species.csv", "r") as file:
        reader = csv.DictReader(file)
        for row in reader:
            create_species(graph, row)

    print("Data seeded successfully")
