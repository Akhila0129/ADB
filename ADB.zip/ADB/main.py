from flask import Flask, jsonify, request
from py2neo import Graph

from Database_Credentials import Database_Url, Database_Username, Database_Password

app = Flask(__name__)


class Service:

    def __init__(self):
        try:
            self.graph = Graph(Database_Url, auth=(Database_Username, Database_Password))
            print("Connected to database")

            # seed_data(self.graph)
        except Exception as e:
            print("Error connecting to database", e)

    def insert_character(self, data):
        query = """
        MERGE (c:Character {name: $name, height: $height, mass: $mass, hair_color: $hair_color, skin_color: $skin_color, 
                           eye_color: $eye_color, birth_year: $birth_year, gender: $gender, homeworld: $homeworld, species: $species})
        MERGE (c)-[:FROM]->(p:Planet {name: $homeworld})
        MERGE (c)-[:IDENTIFIED_AS]->(s:Species {name: $species})
        RETURN properties(c) as character
        """

        result = self.graph.run(query, parameters=data).data()
        return jsonify(result[0]['character']), 201

    def update_character(self, fname, update_data):
        query = """
            MATCH (c:Character)
            WHERE c.name =~ '(?i)' + $fname
            SET c += $props
            RETURN properties(c) as character
            """

        result = self.graph.run(query, parameters={'fname': fname, 'props': update_data}).data()
        if result:
            return jsonify({'message': 'Character updated successfully'}), 200
        else:
            return jsonify({'error': 'Character not found'}), 404

    def delete_character(self, fname):
        query = """
        MATCH (c:Character)
        WHERE c.name =~ '(?i)' + $fname
        DETACH DELETE c
        RETURN count(c) as count_deleted
        """

        result = self.graph.run(query, parameters={'fname': fname}).data()
        if result[0]['count_deleted'] > 0:
            return {'message': f'Character {fname} deleted'}, 200
        else:
            return jsonify({'error': 'Character not found'}), 404

    def get_characters(self):
        query = """
        MATCH (c:Character)-[:FROM]->(p:Planet)
        WITH properties(c) as character, properties(p) as planet
        RETURN collect({character: character, planet: planet}) as characters
        """

        data = self.graph.run(query).data()

        characters = data[0]['characters']
        if len(characters) == 0:
            return jsonify({'error': 'No characters found'}), 404

        return characters

    def get_character(self, fname):
        query = """
        MATCH (c:Character)-[:FROM]->(p:Planet)
        WHERE c.name =~ '(?i)' + $fname
        RETURN {character: properties(c), planet: properties(p)} as result
        LIMIT 1
        """

        data = self.graph.run(query, parameters={'fname': fname}).data()
        if data:
            character = data[0]['result']['character']
            character['planet'] = data[0]['result']['planet']
            return jsonify(character), 200
        else:
            return jsonify({'error': 'Character not found'}), 404


service = Service()


@app.route('/chars', methods=['POST'])
def insert_character():
    data = request.get_json()
    return service.insert_character(data)


@app.route('/chars/<string:fname>', methods=['PATCH'])
def update_character(fname):
    data = request.get_json()
    return service.update_character(fname, data)


@app.route('/chars/<string:fname>', methods=['DELETE'])
def delete_character(fname):
    return service.delete_character(fname)


@app.route('/chars', methods=['GET'])
def get_characters():
    characters = service.get_characters()
    return jsonify(characters), 200


@app.route('/chars/<string:fname>', methods=['GET'])
def get_character(fname):
    return service.get_character(fname)


if __name__ == "__main__":
    app.run(host="localhost", port=4000, debug=True)
